# Los Brous — sitio web

Páginas: `index.html` (Principal) · `los-brous.html` · `herramientas.html` · `descargar.html` (Descargar Minecraft gratis) · `la-serie.html` (Los Brous: la serie, en desarrollo) · `noticias.html` (blog).

## Subirlo a Netlify
Las **noticias** se guardan en el servidor, así que hay que subirlo con GitHub o con la terminal (arrastrar la carpeta a Netlify Drop no instala `@netlify/blobs`; el resto del sitio se vería, pero las noticias no cargarían).

**Con GitHub:** sube el contenido de esta carpeta (no subas `CONTRASEÑAS-PRIVADAS.txt`) → Netlify: *Add new site → Import an existing project*. Sin comando de build; Netlify lee `netlify.toml`.
**Con terminal:** `npm install`, `npx netlify login`, `npx netlify deploy --prod`.

## Contraseñas de los brous
- Cada brou tiene **nombre + contraseña** (están en `CONTRASEÑAS-PRIVADAS.txt`, fuera de esta carpeta). Entrégale a cada uno solo la suya, por privado.
- En el servidor solo se guarda la huella (sha-256), nunca la contraseña.
- **Equipo BROUS** es administrador: puede borrar cualquier publicación. Los demás solo borran las suyas.
- Cambiar una contraseña: `node tools/nueva-contrasena.mjs`, entrega la CONTRASEÑA y pega la HUELLA en `tokenHash` de esa persona en `netlify/functions/api.mjs`. Vuelve a desplegar.
- Agregar otro brou: añádelo en `AUTHORS` (`api.mjs`) y en `PROFILES` (`assets/js/brous-data.js`) con el mismo `id`.

## Cosas útiles
- Al tocar el nombre del autor de una noticia se abre su canal de YouTube.
- Reacciones (me gusta / no me gusta): anónimas, una por navegador y publicación.
- Video destacado: cambia `data-video` en `index.html`.
- Imágenes de las noticias: enlace https de una imagen ya alojada (Imgur, Discord…).
- Los sprites vienen de minecraft.net y pertenecen a Mojang/Microsoft; el pie de página aclara que es un sitio de fans.

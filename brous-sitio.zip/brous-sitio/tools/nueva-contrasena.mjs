// Genera una contraseña nueva y su huella.  Uso:  node tools/nueva-contrasena.mjs
// 1) Entrega la CONTRASEÑA a la persona (por privado).
// 2) Pega la HUELLA en netlify/functions/api.mjs, en el campo tokenHash de esa persona, y vuelve a desplegar.
import { randomInt, createHash } from 'node:crypto';

const ALFABETO = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const raw = Array.from({ length: 16 }, () => ALFABETO[randomInt(ALFABETO.length)]).join('');
const contrasena = raw.match(/.{4}/g).join('-');
const huella = createHash('sha256').update(contrasena.toUpperCase().replace(/[^A-Z0-9]/g, '')).digest('hex');

console.log('CONTRASEÑA (se entrega a la persona):', contrasena);
console.log('HUELLA (va en api.mjs, tokenHash):   ', huella);

/* Datos compartidos de BROUS.
   Para agregar un brou nuevo: añádelo aquí (mismo "id" que en netlify/functions/api.mjs). */
(function(){
  'use strict';

  var PROFILES=[
    {id:'alexlgmc',name:'AlexLGMC',handle:'@alexlgmc',url:'https://youtube.com/@alexlgmc',avatar:'https://unavatar.io/youtube/alexlgmc',accent:'#39a96b',desc:'Minecraft, aventuras y contenido para pasar un buen rato.'},
    {id:'titanicusprime',name:'TitanicusPrime',handle:'@titanicusprime',url:'https://youtube.com/@titanicusprime',avatar:'https://unavatar.io/youtube/titanicusprime',accent:'#8a9cff',desc:'Minecraft, momentos y entretenimiento para la comunidad.'},
    {id:'domi-mc',name:'DOMI MC',handle:'@domi_mc',url:'https://youtube.com/@domi_mc',avatar:'https://unavatar.io/youtube/domi_mc',accent:'#f0a34a',desc:'Contenido de Minecraft con aventuras y momentos divertidos.'},
    {id:'xanilmc',name:'XaniLMC',handle:'@xanilmc',url:'https://youtube.com/@xanilmc',avatar:'https://unavatar.io/youtube/xanilmc',accent:'#48a7ff',desc:'Minecraft y nuevas ideas para descubrir en cada video.'},
    {id:'neon-gd',name:'NEÓN GD',handle:'@neongd-gd',url:'https://youtube.com/@neongd-gd',avatar:'https://unavatar.io/youtube/neongd-gd',accent:'#d85cff',desc:'Minecraft y contenido gaming con estilo propio.'},
    {id:'felixmc',name:'FelixMC',handle:'@FelixGamer-XD',url:'https://www.youtube.com/@FelixGamerMC939',avatar:'https://unavatar.io/youtube/FelixGamerMC939',accent:'#5cc8ff',desc:'Minecraft, entretenimiento y nuevos videos para la comunidad.'},
    {id:'stivechiquito',name:'StiveChiquito',handle:'@stivechiquito',url:'https://youtube.com/@stivechiquito',avatar:'https://unavatar.io/youtube/stivechiquito',accent:'#ff6b6b',desc:'Minecraft y momentos para disfrutar y compartir.'},
    {id:'alexprogamer',name:'AlexProGamer',handle:'@alexprogamer-e8y',url:'https://youtube.com/@alexprogamer-e8y',avatar:'https://unavatar.io/youtube/alexprogamer-e8y',accent:'#ff9a4d',desc:'Contenido gaming con Minecraft como protagonista.'},
    {id:'posnolegend2569',name:'PosNoLegend2569',handle:'@posnolegend2569',url:'https://youtube.com/@posnolegend2569',avatar:'https://unavatar.io/youtube/posnolegend2569',accent:'#9c7cff',desc:'Minecraft, entretenimiento y videos para la comunidad.'},
    {id:'leobros52',name:'LeoBros52',handle:'@leobros52',url:'https://youtube.com/@leobros52',avatar:'https://unavatar.io/youtube/leobros52',accent:'#62d68a',desc:'Aventuras de Minecraft y contenido para descubrir.'}
  ];
  var SECONDARY=[
    {name:'Profe Titanicus Prime',handle:'@profetitanicusprime',url:'https://youtube.com/@profetitanicusprime?si=LOOviJ9xdEtiow1n',avatar:'https://unavatar.io/youtube/profetitanicusprime',accent:'#b18cff',desc:'Canal secundario con más contenido de la comunidad.'},
    {name:'AlexGamer2',handle:'@alexgamer2-w2n',url:'https://youtube.com/@alexgamer2-w2n?si=94mnvFeMgM8hD9ex',avatar:'https://unavatar.io/youtube/alexgamer2-w2n',accent:'#ffb35c',desc:'Canal secundario para más contenido gaming y Minecraft.'}
  ];
  // Cuenta del equipo (sin canal): publica y administra.
  var TEAM={id:'admin',name:'Equipo BROUS',handle:'',url:'',avatar:'',accent:'#6cc349',desc:'',team:true};
  var CATEGORIES=['Noticias','Minecraft','Comunidad','Videos','Avisos'];
  var NEWS_ART=['news-snapshot.webp','news-zombie.webp','news-preview.webp','news-drop.webp','news-avatar.webp','news-marketplace.webp'];

  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
  function initials(name){return (String(name).replace(/[^A-Za-zÁÉÍÓÚÜÑáéíóúüñ]/g,'').slice(0,2).toUpperCase())||'B'}
  // <img> del avatar; si no carga (sin internet o canal sin foto) se cambia por las iniciales
  function avatar(p,alt){
    var name=p&&p.name?p.name:'BROUS';
    if(!p||!p.avatar) return '<span class="avatar-fallback" aria-hidden="true">'+esc(initials(name))+'</span>';
    return '<img src="'+esc(p.avatar)+'" alt="'+esc(alt||'')+'" data-avatar="'+esc(initials(name))+'" loading="lazy" decoding="async" referrerpolicy="no-referrer">';
  }
  document.addEventListener('error',function(e){
    var t=e.target;
    if(t&&t.tagName==='IMG'&&t.dataset&&t.dataset.avatar){
      var s=document.createElement('span');
      s.className='avatar-fallback'; s.setAttribute('aria-hidden','true'); s.textContent=t.dataset.avatar;
      t.replaceWith(s);
    }
  },true);

  var byId={}; PROFILES.concat([TEAM]).forEach(function(p){byId[p.id]=p});
  window.BROUS={profiles:PROFILES,secondary:SECONDARY,team:TEAM,categories:CATEGORIES,newsArt:NEWS_ART,byId:byId,esc:esc,avatar:avatar,initials:initials};
})();

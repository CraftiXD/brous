(function(){
  'use strict';
  var B=window.BROUS, E=B.esc;
  function $(s,r){return (r||document).querySelector(s)}

  /* ---------- Menú móvil ---------- */
  var burger=$('.mc-burger'), nav=$('#mc-nav');
  if(burger&&nav){
    var setOpen=function(open){
      burger.setAttribute('aria-expanded',String(open));
      burger.setAttribute('aria-label',open?'Cerrar menú':'Abrir menú');
      nav.classList.toggle('open',open);
      document.body.style.overflow=open?'hidden':'';
    };
    burger.addEventListener('click',function(){setOpen(burger.getAttribute('aria-expanded')!=='true')});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')setOpen(false)});
    nav.addEventListener('click',function(e){if(e.target.closest('a'))setOpen(false)});
    window.addEventListener('resize',function(){if(window.innerWidth>980)setOpen(false)});
  }

  /* ---------- Año del pie ---------- */
  var yr=$('#year'); if(yr) yr.textContent=new Date().getFullYear();

  /* ---------- Carrusel de brous (portada) ---------- */
  var track=$('#brouTrack');
  if(track){
    track.innerHTML=B.profiles.map(function(p){
      return '<a class="car-card" href="'+E(p.url)+'" target="_blank" rel="noopener noreferrer" style="--accent:'+E(p.accent)+'">'
        +'<div class="pic">'+B.avatar(p,'')+'</div>'
        +'<h3>'+E(p.name)+'</h3><span class="by">'+E(p.handle)+'</span>'
        +'<div class="row"><span class="chip">YouTube</span><span class="go">Ver canal</span></div></a>';
    }).join('');
    var step=function(dir){track.scrollBy({left:dir*(track.firstElementChild?track.firstElementChild.getBoundingClientRect().width+20:240)*2,behavior:'smooth'})};
    var prev=$('#carPrev'), next=$('#carNext');
    if(prev) prev.addEventListener('click',function(){step(-1)});
    if(next) next.addEventListener('click',function(){step(1)});
  }

  /* ---------- Página Los Brous ---------- */
  var grid=$('#brouGrid');
  if(grid){
    grid.innerHTML=B.profiles.map(function(p){
      return '<a class="brou" href="'+E(p.url)+'" target="_blank" rel="noopener noreferrer" style="--accent:'+E(p.accent)+'" aria-label="Abrir el canal de YouTube de '+E(p.name)+'">'
        +'<div class="head"></div><div class="av">'+B.avatar(p,'')+'</div>'
        +'<div class="body"><h3>'+E(p.name)+'</h3><span class="handle">'+E(p.handle)+'</span><p>'+E(p.desc)+'</p>'
        +'<span class="go">Ver canal <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M7 17 17 7M9 7h8v8"/></svg></span></div></a>';
    }).join('');
  }
  var sec=$('#brouSecondary');
  if(sec){
    sec.innerHTML=B.secondary.map(function(p){
      return '<a class="brou" href="'+E(p.url)+'" target="_blank" rel="noopener noreferrer" style="--accent:'+E(p.accent)+'" aria-label="Abrir el canal de YouTube '+E(p.name)+'">'
        +'<div class="head"></div><div class="av">'+B.avatar(p,'')+'</div>'
        +'<div class="body"><h3>'+E(p.name)+'</h3><span class="handle">'+E(p.handle)+'</span><p>'+E(p.desc)+'</p>'
        +'<span class="go">Ver canal <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M7 17 17 7M9 7h8v8"/></svg></span></div></a>';
    }).join('');
  }

  /* ---------- Reparto de la serie ---------- */
  var cast=$('#cast');
  if(cast){
    cast.innerHTML=B.profiles.map(function(p){
      return '<a href="'+E(p.url)+'" target="_blank" rel="noopener noreferrer" style="--accent:'+E(p.accent)+'"><div class="av">'+B.avatar(p,'')+'</div><strong>'+E(p.name)+'</strong></a>';
    }).join('');
  }

  /* ---------- Últimas noticias en la portada ---------- */
  var home=$('#homeNews');
  if(home){
    var art=function(i){return '../img/'+B.newsArt[i%B.newsArt.length]};
    var empty=function(msg){home.innerHTML='<div class="news-empty">'+msg+'</div>'};
    var ctl=new AbortController(), to=setTimeout(function(){ctl.abort()},8000);
    fetch('/api/posts',{signal:ctl.signal,headers:{'accept':'application/json'}}).then(function(r){
      clearTimeout(to);
      if(!r.ok) throw new Error('http');
      return r.json();
    }).then(function(d){
      var posts=(d&&d.posts||[]).slice(0,8);
      if(!posts.length){empty('Todavía no hay noticias publicadas. <a href="noticias.html">Ir al apartado de noticias</a>');return}
      home.innerHTML='';
      posts.forEach(function(p,idx){
        var a=document.createElement('a');
        a.className='news-card'; a.href='noticias.html#'+encodeURIComponent(p.id);
        var img=p.image?String(p.image).replace(/["'\\\n\r()]/g,''):art(idx);
        a.style.setProperty('--img','url("'+img+'")');
        var cap=document.createElement('div'); cap.className='cap';
        var tag=document.createElement('span'); tag.className='tag'; tag.textContent=p.category;
        var h=document.createElement('h3'); h.textContent=p.title;
        var by=document.createElement('div'); by.className='by'; by.textContent='Por '+p.authorName;
        cap.append(tag,h,by); a.append(cap); home.append(a);
      });
    }).catch(function(){
      empty('Las noticias se cargan desde el servidor del sitio. <a href="noticias.html">Abrir el apartado de noticias</a>');
    });
  }
})();

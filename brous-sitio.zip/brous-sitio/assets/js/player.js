/* Reproductor del video destacado.
   Para cambiar de video: edita data-video="..." en <div id="player"> (la miniatura se actualiza sola). */
(function(){
  'use strict';
  var box=document.getElementById('player');
  if(!box) return;
  var VIDEO=box.dataset.video;
  var playBtn=document.getElementById('playBtn');
  var poster=document.getElementById('posterImg');
  var stage=document.getElementById('stage');
  var fallback=document.getElementById('fallback');
  var fbText=document.getElementById('fbText');
  var retryBtn=document.getElementById('retryBtn');
  var isLocal=location.protocol==='file:';
  var player=null, apiPromise=null, timer=null;

  poster.src='https://i.ytimg.com/vi/'+VIDEO+'/hqdefault.jpg';
  poster.addEventListener('error',function(){
    if(!poster.dataset.tried){poster.dataset.tried='1';poster.src='https://i.ytimg.com/vi/'+VIDEO+'/default.jpg';}
    else poster.style.visibility='hidden';
  });

  function loadApi(){
    if(window.YT&&window.YT.Player) return Promise.resolve();
    if(apiPromise) return apiPromise;
    apiPromise=new Promise(function(resolve,reject){
      var prev=window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady=function(){ if(typeof prev==='function') prev(); resolve(); };
      var s=document.createElement('script');
      s.src='https://www.youtube.com/iframe_api'; s.async=true;
      s.onerror=function(){apiPromise=null;reject(new Error('api'))};
      document.head.appendChild(s);
    });
    return apiPromise;
  }
  function cleanup(){
    clearTimeout(timer);
    box.classList.remove('is-loading');
    if(player&&typeof player.destroy==='function'){try{player.destroy()}catch(_){}}
    player=null; stage.innerHTML='';
  }
  function fail(message){
    cleanup(); stage.hidden=true; playBtn.hidden=true;
    fbText.textContent=message; fallback.hidden=false;
  }
  function errorMessage(code){
    if(code===101||code===150) return 'El dueño del video no permite reproducirlo fuera de YouTube.';
    if(code===100) return 'El video no está disponible o es privado.';
    if(code===153||code===152){
      return isLocal
        ? 'YouTube no reproduce videos dentro de archivos abiertos desde el dispositivo (file://). Sube la página a Netlify y el video se verá aquí mismo.'
        : 'YouTube no recibió el origen de la página. Revisa que el navegador o una extensión no esté bloqueando el referrer.';
    }
    return 'YouTube no dejó cargar el video dentro de la página (código '+code+').';
  }
  function start(){
    fallback.hidden=true; playBtn.hidden=true; stage.hidden=false;
    stage.innerHTML='<div id="ytTarget"></div>';
    box.classList.add('is-loading');
    clearTimeout(timer);
    timer=setTimeout(function(){fail('El video tardó demasiado en cargar. Revisa tu conexión o un bloqueador de contenido.')},15000);
    loadApi().then(function(){
      var vars={autoplay:1,rel:0,playsinline:1,modestbranding:1};
      if(/^https?:$/.test(location.protocol)) vars.origin=location.origin;
      player=new YT.Player('ytTarget',{
        videoId:VIDEO,width:'100%',height:'100%',playerVars:vars,
        events:{
          onReady:function(e){clearTimeout(timer);box.classList.remove('is-loading');try{e.target.playVideo()}catch(_){}},
          onError:function(e){fail(errorMessage(e.data))}
        }
      });
    }).catch(function(){fail('No se pudo conectar con YouTube. Revisa tu conexión o un bloqueador de contenido.')});
  }
  playBtn.addEventListener('click',start);
  retryBtn.addEventListener('click',start);
})();

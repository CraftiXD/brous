/* Noticias de BROUS — todos leen y reaccionan; publican solo los brous con nombre + contraseña. */
(function(){
  'use strict';
  var B=window.BROUS, E=B.esc, PROFILES=B.profiles, TEAM=B.team, CATEGORIES=B.categories, byId=B.byId;
  function $(s,r){return (r||document).querySelector(s)}

  var mem={};
  var local={
    get:function(k){try{return localStorage.getItem(k)}catch(e){return mem[k]==null?null:mem[k]}},
    set:function(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}},
    del:function(k){try{localStorage.removeItem(k)}catch(e){delete mem[k]}}
  };
  var sess={
    get:function(k){try{return sessionStorage.getItem(k)}catch(e){return mem['s'+k]==null?null:mem['s'+k]}},
    set:function(k,v){try{sessionStorage.setItem(k,v)}catch(e){mem['s'+k]=v}},
    del:function(k){try{sessionStorage.removeItem(k)}catch(e){delete mem['s'+k]}}
  };

  // Identificador anónimo del visitante (para que cada navegador vote una vez por publicación)
  var voter=local.get('brous-voter');
  if(!/^[a-zA-Z0-9-]{16,64}$/.test(voter||'')){
    voter=(window.crypto&&crypto.randomUUID)?crypto.randomUUID():Array.prototype.map.call(crypto.getRandomValues(new Uint8Array(16)),function(b){return b.toString(16).padStart(2,'0')}).join('');
    local.set('brous-voter',voter);
  }

  var ICON_EXT='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8"/></svg>';
  var ICON_UP='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 11v9H4a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1h3zm0 0 4-8a2.2 2.2 0 0 1 2.2 2.4L12.8 9H19a2 2 0 0 1 2 2.3l-1.3 7A2 2 0 0 1 17.7 20H7"/></svg>';
  var ICON_DOWN='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17 13V4h3a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1h-3zm0 0-4 8a2.2 2.2 0 0 1-2.2-2.4L11.2 15H5a2 2 0 0 1-2-2.3l1.3-7A2 2 0 0 1 6.3 4H17"/></svg>';

  function fmtDate(iso){
    var d=new Date(iso); if(isNaN(d)) return '';
    var diff=(d.getTime()-Date.now())/1000, abs=Math.abs(diff), text;
    var rtf=new Intl.RelativeTimeFormat('es',{numeric:'auto'});
    if(abs<60) text='justo ahora';
    else if(abs<3600) text=rtf.format(Math.round(diff/60),'minute');
    else if(abs<86400) text=rtf.format(Math.round(diff/3600),'hour');
    else if(abs<7*86400) text=rtf.format(Math.round(diff/86400),'day');
    else text=d.toLocaleDateString('es',{day:'numeric',month:'short',year:'numeric'});
    var full=d.toLocaleString('es',{dateStyle:'long',timeStyle:'short'});
    return '<time datetime="'+E(d.toISOString())+'" title="'+E(full)+'">'+E(text)+'</time>';
  }
  // texto escapado + enlaces https clicables
  function renderText(text){
    return E(text).replace(/https:\/\/[^\s<]+/g,function(m){
      var trail=(m.match(/(?:&quot;|&#39;|[.,;:!?)\]])+$/)||[''])[0];
      var url=m.slice(0,m.length-trail.length);
      return '<a href="'+url+'" target="_blank" rel="noopener noreferrer nofollow">'+url+'</a>'+trail;
    });
  }
  function truncate(t,max){
    if(t.length<=max) return t;
    var cut=t.slice(0,max);
    return cut.slice(0,Math.max(cut.lastIndexOf(' '),max-40)).trimEnd()+'…';
  }

  var toastTimer;
  function toast(msg){
    var t=$('#toast'); t.textContent=msg; t.classList.add('show');
    clearTimeout(toastTimer); toastTimer=setTimeout(function(){t.classList.remove('show')},3200);
  }

  /* ---------- API ---------- */
  var NO_SERVER='El servidor de noticias no responde. Si abriste este archivo desde tu dispositivo, súbelo a Netlify (con GitHub o la terminal): las publicaciones solo funcionan allí.';
  function api(path,opts){
    opts=opts||{};
    return fetch('/api'+path,{method:opts.method||'GET',headers:{'content-type':'application/json','x-voter':voter},body:opts.body?JSON.stringify(opts.body):undefined})
      .catch(function(){throw Object.assign(new Error(location.protocol==='file:'?NO_SERVER:'No se pudo conectar. Revisa tu conexión e inténtalo de nuevo.'),{network:true})})
      .then(function(res){
        return res.json().catch(function(){return null}).then(function(data){
          if(!res.ok||!data){
            var msg=data&&data.error?data.error:(res.status===404?NO_SERVER:'Error del servidor ('+res.status+').');
            throw Object.assign(new Error(msg),{status:res.status});
          }
          return data;
        });
      });
  }

  /* ---------- Estado ---------- */
  var state={posts:[],loading:true,error:null,category:'all',author:null,expanded:{},session:null,pending:{},afterLogin:null};
  var lastSnapshot='';

  /* ---------- Sesión ---------- */
  function renderSession(){
    var el=$('#sessionNote'), s=state.session;
    if(s){
      el.innerHTML='<span>Publicando como <strong>'+E(s.name)+'</strong>'+(s.role==='admin'?' (admin)':'')+'</span><button class="btn btn-small" id="publishBtn" type="button">Publicar</button><button class="btn btn-outline-green" id="logoutBtn" type="button">Cerrar sesión</button>';
    }else{
      el.innerHTML='<span>¿Eres uno de los brous?</span><button class="btn btn-outline-green" id="enterBtn" type="button">Entrar para publicar</button>';
    }
  }
  function saveSession(name,password,remember){
    var data=JSON.stringify({name:name,token:password});
    sess.set('brous-session',data);
    if(remember) local.set('brous-session',data); else local.del('brous-session');
  }
  function clearSession(){sess.del('brous-session');local.del('brous-session')}
  function restoreSession(){
    var saved=null;
    try{saved=JSON.parse(sess.get('brous-session')||local.get('brous-session')||'null')}catch(e){}
    if(!saved||!saved.name||!saved.token) return;
    api('/login',{method:'POST',body:{name:saved.name,token:saved.token}}).then(function(r){
      state.session=Object.assign({},r.author,{token:saved.token});
      renderSession(); renderAll();
    }).catch(function(e){ if(e.status===401) clearSession(); });
  }
  function logout(){
    state.session=null; clearSession(); renderSession(); renderAll(); toast('Sesión cerrada');
  }

  /* ---------- Render ---------- */
  function visiblePosts(){
    return state.posts.filter(function(p){return (state.category==='all'||p.category===state.category)&&(!state.author||p.authorId===state.author)});
  }
  function renderChips(){
    var items=[['all','Todo']].concat(CATEGORIES.map(function(c){return [c,c]}));
    $('#chips').innerHTML=items.map(function(i){return '<button type="button" data-act="chip" data-v="'+E(i[0])+'" aria-pressed="'+(state.category===i[0])+'">'+E(i[1])+'</button>'}).join('');
  }
  function renderBanner(){
    var el=$('#authorBanner'), p=state.author&&byId[state.author];
    if(!p){el.innerHTML='';return}
    var n=state.posts.filter(function(x){return x.authorId===p.id}).length;
    el.innerHTML='<div class="note" style="margin-bottom:20px;align-items:center;flex-wrap:wrap"><span><strong>'+E(p.name)+'</strong> · '+n+(n===1?' publicación':' publicaciones')+'</span>'
      +(p.url?'<a class="btn btn-small btn-outline-green" href="'+E(p.url)+'" target="_blank" rel="noopener noreferrer">Ver canal '+ICON_EXT+'</a>':'')
      +'<button class="btn btn-small btn-outline-green" type="button" data-act="clear-author">Quitar filtro</button></div>';
  }
  function reactionsHtml(p){
    var on=function(k){return p.myReaction===k};
    var dis=state.pending[p.id]?' disabled':'';
    return '<button class="react" type="button" data-act="react" data-kind="like" aria-pressed="'+on('like')+'" aria-label="Me gusta"'+dis+'>'+ICON_UP+'<span>'+p.likes+'</span></button>'
      +'<button class="react" type="button" data-act="react" data-kind="dislike" aria-pressed="'+on('dislike')+'" aria-label="No me gusta"'+dis+'>'+ICON_DOWN+'<span>'+p.dislikes+'</span></button>';
  }
  function postHtml(p){
    var prof=byId[p.authorId], name=p.authorName||(prof&&prof.name)||'BROUS';
    var s=state.session, canDelete=s&&(s.role==='admin'||s.id===p.authorId);
    var isLong=p.body.length>480, open=!!state.expanded[p.id];
    var shown=isLong&&!open?truncate(p.body,420):p.body;
    var who=B.avatar(prof,'')+'<span>'+E(name)+'</span>'+(prof&&prof.url?ICON_EXT:'');
    var byline=prof&&prof.url
      ? '<a class="by-link" href="'+E(prof.url)+'" target="_blank" rel="noopener noreferrer" title="Abrir el canal de YouTube de '+E(name)+'">'+who+'</a>'
      : '<span class="by-link">'+who+'</span>';
    return '<article class="post" id="post-'+E(p.id)+'" data-id="'+E(p.id)+'">'
      +(p.image?'<div class="cover"><img src="'+E(p.image)+'" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer"></div>':'')
      +'<div class="in"><div class="meta"><span class="tag" style="margin:0">'+E(p.category)+'</span>'+byline+fmtDate(p.createdAt)+'</div>'
      +'<h2>'+E(p.title)+'</h2>'
      +'<div class="txt">'+renderText(shown)+'</div>'
      +(isLong?'<p style="margin-top:10px"><button class="del" style="margin:0;color:var(--green-2)" type="button" data-act="more">'+(open?'Mostrar menos':'Leer más')+'</button></p>':'')
      +'<div class="acts" role="group" aria-label="Reacciones">'+reactionsHtml(p)+(canDelete?'<button class="del" type="button" data-act="delete">Borrar</button>':'')+'</div></div></article>';
  }
  function renderFeed(){
    var feed=$('#feed');
    if(state.loading&&!state.posts.length){feed.innerHTML='<div class="skeleton"></div><div class="skeleton"></div>';return}
    if(state.error&&!state.posts.length){
      feed.innerHTML='<div class="api-error"><strong>No se pudieron cargar las noticias</strong>'+E(state.error)+'<p style="margin-top:14px"><button class="btn btn-small" type="button" data-act="retry">Reintentar</button></p></div>';
      return;
    }
    var list=visiblePosts();
    if(!list.length){
      var filtered=state.category!=='all'||state.author;
      feed.innerHTML=filtered
        ?'<div class="news-empty"><strong>No hay publicaciones con este filtro</strong><br>Prueba con otra categoría o quita el filtro.</div>'
        :'<div class="news-empty"><strong>Todavía no hay noticias</strong><br>Cuando los brous publiquen, las verás aquí. Podrás reaccionar con me gusta o no me gusta.</div>';
      return;
    }
    feed.innerHTML=list.map(postHtml).join('');
  }
  function renderSide(){
    $('#side').innerHTML='<div class="side-box"><h3>Los brous</h3><ul class="side-list">'
      +PROFILES.map(function(p){
        var n=state.posts.filter(function(x){return x.authorId===p.id}).length;
        return '<li><a href="#" data-act="filter-author" data-id="'+E(p.id)+'" aria-pressed="'+(state.author===p.id)+'"'+(state.author===p.id?' style="background:var(--grey-5)"':'')+'>'+B.avatar(p,'')+'<span style="flex:1">'+E(p.name)+'</span><span class="chip">'+n+'</span></a></li>';
      }).join('')+'</ul></div>'
      +'<div class="side-box"><h3>¿Quieres publicar?</h3><p style="font-size:14px;color:var(--grey-2);margin-bottom:12px">Cada brou tiene su nombre y su contraseña. Entra y escribe tu noticia.</p><button class="btn btn-small" type="button" data-act="open-publish">Publicar</button></div>';
  }
  function renderAll(){renderChips();renderBanner();renderFeed();renderSide()}

  /* ---------- Carga ---------- */
  function loadPosts(silent){
    if(!silent){state.loading=true;state.error=null;renderFeed()}
    return api('/posts').then(function(r){
      var snap=JSON.stringify(r.posts);
      state.error=null; state.loading=false;
      var pend=Object.keys(state.pending).length;
      if(snap!==lastSnapshot&&!pend){lastSnapshot=snap;state.posts=r.posts;renderAll();goToHash(false)}
      else if(!silent) renderFeed();
    }).catch(function(e){
      state.loading=false;
      if(!silent){state.error=e.message;renderFeed()}
    });
  }
  var hashDone=false;
  function goToHash(force){
    if(hashDone&&!force) return;
    var id=decodeURIComponent((location.hash||'').slice(1)); if(!id) return;
    var el=document.getElementById('post-'+id); if(!el) return;
    hashDone=true;
    el.scrollIntoView({block:'start'});
    el.style.outline='3px solid var(--gold-3)'; setTimeout(function(){el.style.outline=''},2600);
  }

  /* ---------- Reacciones ---------- */
  function react(id,kind){
    var p=state.posts.filter(function(x){return x.id===id})[0]; if(!p||state.pending[id]) return;
    var prev={likes:p.likes,dislikes:p.dislikes,myReaction:p.myReaction};
    var next=p.myReaction===kind?'none':kind;
    if(p.myReaction==='like') p.likes--; if(p.myReaction==='dislike') p.dislikes--;
    if(next==='like') p.likes++; if(next==='dislike') p.dislikes++;
    p.myReaction=next==='none'?null:next;
    state.pending[id]=true; updateReactions(p);
    api('/posts/'+encodeURIComponent(id)+'/react',{method:'POST',body:{reaction:next}}).then(function(r){
      p.likes=r.likes; p.dislikes=r.dislikes; p.myReaction=r.myReaction;
    }).catch(function(e){Object.assign(p,prev);toast(e.message)}).then(function(){
      delete state.pending[id]; lastSnapshot=JSON.stringify(state.posts); updateReactions(p);
    });
  }
  function updateReactions(p){
    var art=document.getElementById('post-'+p.id); if(!art) return;
    var box=$('.acts',art), del=$('.del',box);
    box.innerHTML=reactionsHtml(p)+(del?del.outerHTML:'');
  }

  /* ---------- Borrar ---------- */
  function removePost(id){
    var s=state.session; if(!s) return;
    if(!confirm('¿Borrar esta publicación? No se puede deshacer.')) return;
    api('/posts/'+encodeURIComponent(id),{method:'DELETE',body:{name:s.name,token:s.token}}).then(function(){
      state.posts=state.posts.filter(function(p){return p.id!==id}); lastSnapshot=JSON.stringify(state.posts);
      renderAll(); toast('Publicación borrada');
    }).catch(function(e){ if(e.status===401) logout(); toast(e.message); });
  }

  /* ---------- Ventanas ---------- */
  document.querySelectorAll('dialog').forEach(function(dlg){
    dlg.addEventListener('click',function(e){if(e.target===dlg)dlg.close()});
    dlg.querySelectorAll('[data-close]').forEach(function(b){b.addEventListener('click',function(){dlg.close()})});
  });
  function openLogin(thenCompose){
    state.afterLogin=thenCompose?'compose':null;
    $('#loginError').textContent=''; $('#loginToken').value='';
    var d=$('#loginDlg'); if(!d.open) d.showModal(); $('#loginName').focus();
  }
  function openCompose(){
    if(!state.session){openLogin(true);return}
    $('#composeLead').textContent='Publicando como '+state.session.name+'. Todo el mundo podrá leerlo.';
    $('#composeError').textContent='';
    var d=$('#composeDlg'); if(!d.open) d.showModal(); $('#postTitle').focus();
  }
  $('#nameList').innerHTML=PROFILES.concat([TEAM]).map(function(p){return '<option value="'+E(p.name)+'"></option>'}).join('');
  $('#postCategory').innerHTML=CATEGORIES.map(function(c){return '<option>'+E(c)+'</option>'}).join('');
  $('#toggleToken').addEventListener('click',function(e){
    var inp=$('#loginToken'), show=inp.type==='password';
    inp.type=show?'text':'password'; e.currentTarget.textContent=show?'Ocultar':'Mostrar'; e.currentTarget.setAttribute('aria-pressed',String(show));
  });

  $('#loginForm').addEventListener('submit',function(e){
    e.preventDefault();
    var name=$('#loginName').value.trim(), pass=$('#loginToken').value.trim(), btn=$('#loginSubmit');
    $('#loginError').textContent=''; btn.disabled=true;
    api('/login',{method:'POST',body:{name:name,token:pass}}).then(function(r){
      state.session=Object.assign({},r.author,{token:pass});
      saveSession(name,pass,$('#rememberMe').checked);
      $('#loginDlg').close(); renderSession(); renderAll(); toast('Hola, '+r.author.name);
      if(state.afterLogin==='compose') openCompose();
    }).catch(function(err){$('#loginError').textContent=err.message}).then(function(){btn.disabled=false});
  });
  $('#postBody').addEventListener('input',function(){$('#bodyCount').textContent=$('#postBody').value.length+' / 8000'});
  $('#composeForm').addEventListener('submit',function(e){
    e.preventDefault();
    var s=state.session; if(!s) return;
    var btn=$('#composeSubmit'); btn.disabled=true; $('#composeError').textContent='';
    api('/posts',{method:'POST',body:{name:s.name,token:s.token,category:$('#postCategory').value,title:$('#postTitle').value,image:$('#postImage').value,body:$('#postBody').value}}).then(function(r){
      state.posts.unshift(r.post); lastSnapshot=JSON.stringify(state.posts);
      $('#composeForm').reset(); $('#bodyCount').textContent='0 / 8000';
      $('#composeDlg').close(); state.category='all'; state.author=null; renderAll(); toast('Publicado');
      window.scrollTo({top:0,behavior:'smooth'});
    }).catch(function(err){
      if(err.status===401){$('#composeDlg').close();logout();openLogin(true)}
      $('#composeError').textContent=err.message;
    }).then(function(){btn.disabled=false});
  });

  /* ---------- Eventos ---------- */
  document.addEventListener('click',function(e){
    var t=e.target.closest('[data-act],#publishBtn,#enterBtn,#logoutBtn'); if(!t) return;
    if(t.id==='publishBtn'){openCompose();return}
    if(t.id==='enterBtn'){openLogin(false);return}
    if(t.id==='logoutBtn'){logout();return}
    var act=t.dataset.act;
    if(act==='chip'){state.category=t.dataset.v;renderChips();renderFeed()}
    else if(act==='filter-author'){e.preventDefault();state.author=state.author===t.dataset.id?null:t.dataset.id;renderAll();window.scrollTo({top:$('#feed').offsetTop-140,behavior:'smooth'})}
    else if(act==='clear-author'){state.author=null;renderAll()}
    else if(act==='open-publish'){openCompose()}
    else if(act==='retry'){loadPosts(false)}
    else if(act==='more'){var id=t.closest('.post').dataset.id;state.expanded[id]=!state.expanded[id];renderFeed()}
    else if(act==='react'){react(t.closest('.post').dataset.id,t.dataset.kind)}
    else if(act==='delete'){removePost(t.closest('.post').dataset.id)}
  });

  /* ---------- Inicio ---------- */
  renderSession(); renderAll(); restoreSession(); loadPosts(false);
  setInterval(function(){if(!document.hidden&&!$('dialog[open]')) loadPosts(true)},45000);
  window.addEventListener('hashchange',function(){goToHash(true)});
})();

// Servidor del blog BROUS (Netlify Function + Netlify Blobs).
// Ruta: /api/*  ·  Guarda publicaciones y reacciones; valida nombre + token para publicar.
import { getStore } from '@netlify/blobs';
import { createHash, timingSafeEqual, randomBytes } from 'node:crypto';

// Autores con permiso de publicar. Aquí solo hay HUELLAS (sha-256) de las contraseñas, nunca la contraseña en claro.
// role: 'admin' puede borrar cualquier publicación; 'brou' solo las suyas.
// Para cambiar una contraseña: node tools/nueva-contrasena.mjs  y pega la huella nueva en tokenHash.
const AUTHORS = [
  {
    "id": "admin",
    "name": "Equipo BROUS",
    "role": "admin",
    "tokenHash": "b5e9389bd2c503764f79eead9206a8f31408863a3b09fc338398b7e480e0f2a9"
  },
  {
    "id": "alexlgmc",
    "name": "AlexLGMC",
    "role": "brou",
    "tokenHash": "fa0f6f3720b4c59145aeabc7afe7fec83e89840f5d62d06bd018d725414a40af"
  },
  {
    "id": "titanicusprime",
    "name": "TitanicusPrime",
    "role": "brou",
    "tokenHash": "17eebe1511a8bbc6d8c693ebd5bc1c460c1aecc213f7822385a018b1ab576372"
  },
  {
    "id": "domi-mc",
    "name": "DOMI MC",
    "role": "brou",
    "tokenHash": "bfa78e9199d7714ca7c02b4a3cd576f2a5a8ebcbaae51f75571c93db0187e38b"
  },
  {
    "id": "xanilmc",
    "name": "XaniLMC",
    "role": "brou",
    "tokenHash": "7fd7a7c6b2265c7cc640b84a185bfa9a2a6cd928a3c4aafe4578d0d560ff8dca"
  },
  {
    "id": "neon-gd",
    "name": "NEÓN GD",
    "role": "brou",
    "tokenHash": "14e6cf3c75620ded6e0d161c7bb0d4246ef5a1ac445f616146d84f447513eae3"
  },
  {
    "id": "felixmc",
    "name": "FelixMC",
    "role": "brou",
    "tokenHash": "54b0c53885c9eb5a0fbcc4b9c779edecca52ab838537bec0ce820a22c2391198"
  },
  {
    "id": "stivechiquito",
    "name": "StiveChiquito",
    "role": "brou",
    "tokenHash": "9374f500fae2e78df0288f4d65e184ed1fb607f5618577be82d1c95d754fd057"
  },
  {
    "id": "alexprogamer",
    "name": "AlexProGamer",
    "role": "brou",
    "tokenHash": "07d229c4186950026f36476beace658dd012a01d73b8dccb3147787bc5ef85e7"
  },
  {
    "id": "posnolegend2569",
    "name": "PosNoLegend2569",
    "role": "brou",
    "tokenHash": "e49420891a9df843a8198249a488d466152008930c57ddd957fbc5f767edefda"
  },
  {
    "id": "leobros52",
    "name": "LeoBros52",
    "role": "brou",
    "tokenHash": "2600fda53d9fa7c1e8c058c6639cdc8d4e16d1dc29a079aaac74a65acc928730"
  }
];

const CATEGORIES = ['Noticias', 'Minecraft', 'Comunidad', 'Videos', 'Avisos'];
const MAX = { title: 120, body: 8000, image: 500, request: 30000 };
const ID_RE = /^\d{13}-[a-f0-9]{6}$/;
const VOTER_RE = /^[a-zA-Z0-9-]{16,64}$/;

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
  });
const fail = (status, message) => json({ error: message }, status);

const normName = (s) =>
  String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase().replace(/\s+/g, ' ');
const hashToken = (t) =>
  createHash('sha256').update(String(t || '').toUpperCase().replace(/[^A-Z0-9]/g, '')).digest();

// Devuelve el autor si el nombre y el token coinciden; si no, null. Compara todo para no filtrar tiempos.
function authenticate(name, token) {
  if (!name || !token) return null;
  const h = hashToken(token);
  let found = null;
  for (const a of AUTHORS) {
    const same = timingSafeEqual(h, Buffer.from(a.tokenHash, 'hex'));
    if (same && normName(a.name) === normName(name)) found = a;
  }
  return found;
}
const publicAuthor = (a) => ({ id: a.id, name: a.name, role: a.role });

const store = () => getStore({ name: 'brous-blog', consistency: 'strong' });

async function readBody(req) {
  const text = await req.text();
  if (text.length > MAX.request) throw Object.assign(new Error('Solicitud demasiado grande'), { status: 413 });
  if (!text) return {};
  try {
    const data = JSON.parse(text);
    return data && typeof data === 'object' ? data : {};
  } catch {
    throw Object.assign(new Error('JSON inválido'), { status: 400 });
  }
}

const clean = (v, max) => String(v ?? '').replace(/\r\n/g, '\n').trim().slice(0, max);

function tally(keys, voter) {
  const counts = new Map();
  const mine = new Map();
  for (const key of keys) {
    const m = /^r\/([^/]+)\/([a-zA-Z0-9-]+)\.(like|dislike)$/.exec(key);
    if (!m) continue;
    const [, postId, voterId, kind] = m;
    const c = counts.get(postId) || { likes: 0, dislikes: 0 };
    if (kind === 'like') c.likes++;
    else c.dislikes++;
    counts.set(postId, c);
    if (voter && voterId === voter) mine.set(postId, kind);
  }
  return { counts, mine };
}

async function listPosts(req) {
  const s = store();
  const voter = req.headers.get('x-voter');
  const [posts, reacts] = await Promise.all([s.list({ prefix: 'p/' }), s.list({ prefix: 'r/' })]);
  const keys = posts.blobs.map((b) => b.key).sort().slice(0, 100); // claves con fecha invertida: las nuevas primero
  const items = (await Promise.all(keys.map((k) => s.get(k, { type: 'json' })))).filter(Boolean);
  const { counts, mine } = tally(reacts.blobs.map((b) => b.key), VOTER_RE.test(voter || '') ? voter : null);
  items.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)));
  return json({
    posts: items.map((p) => ({
      ...p,
      likes: counts.get(p.id)?.likes || 0,
      dislikes: counts.get(p.id)?.dislikes || 0,
      myReaction: mine.get(p.id) || null,
    })),
  });
}

async function createPost(req) {
  const body = await readBody(req);
  const author = authenticate(body.name, body.token);
  if (!author) return fail(401, 'Nombre o contraseña incorrectos.');

  const title = clean(body.title, MAX.title);
  const text = clean(body.body, MAX.body);
  const category = CATEGORIES.includes(body.category) ? body.category : null;
  let image = clean(body.image, MAX.image);

  if (!title) return fail(400, 'Falta el título.');
  if (!text) return fail(400, 'Falta el texto de la publicación.');
  if (!category) return fail(400, 'Categoría no válida.');
  if (image) {
    try {
      const u = new URL(image);
      if (u.protocol !== 'https:') throw new Error('x');
      image = u.href;
    } catch {
      return fail(400, 'La imagen debe ser un enlace https válido.');
    }
  }

  const id = String(9e12 - Date.now()).padStart(13, '0') + '-' + randomBytes(3).toString('hex');
  const post = {
    id, title, category, body: text, image,
    authorId: author.id, authorName: author.name, createdAt: new Date().toISOString(),
  };
  await store().setJSON('p/' + id, post);
  return json({ post: { ...post, likes: 0, dislikes: 0, myReaction: null } }, 201);
}

async function deletePost(req, id) {
  if (!ID_RE.test(id)) return fail(404, 'Publicación no encontrada.');
  const body = await readBody(req);
  const author = authenticate(body.name, body.token);
  if (!author) return fail(401, 'Nombre o contraseña incorrectos.');
  const s = store();
  const post = await s.get('p/' + id, { type: 'json' });
  if (!post) return fail(404, 'Publicación no encontrada.');
  if (author.role !== 'admin' && post.authorId !== author.id) return fail(403, 'Solo puedes borrar tus propias publicaciones.');
  const { blobs } = await s.list({ prefix: `r/${id}/` });
  await Promise.all([s.delete('p/' + id), ...blobs.map((b) => s.delete(b.key))]);
  return json({ ok: true });
}

async function react(req, id) {
  if (!ID_RE.test(id)) return fail(404, 'Publicación no encontrada.');
  const voter = req.headers.get('x-voter') || '';
  if (!VOTER_RE.test(voter)) return fail(400, 'Identificador de votante no válido.');
  const body = await readBody(req);
  const reaction = body.reaction;
  if (!['like', 'dislike', 'none'].includes(reaction)) return fail(400, 'Reacción no válida.');
  const s = store();
  if (!(await s.get('p/' + id, { type: 'json' }))) return fail(404, 'Publicación no encontrada.');

  const base = `r/${id}/${voter}`;
  if (reaction === 'like') await Promise.all([s.set(base + '.like', '1'), s.delete(base + '.dislike')]);
  else if (reaction === 'dislike') await Promise.all([s.set(base + '.dislike', '1'), s.delete(base + '.like')]);
  else await Promise.all([s.delete(base + '.like'), s.delete(base + '.dislike')]);

  const { blobs } = await s.list({ prefix: `r/${id}/` });
  const { counts } = tally(blobs.map((b) => b.key), null);
  const c = counts.get(id) || { likes: 0, dislikes: 0 };
  return json({ id, likes: c.likes, dislikes: c.dislikes, myReaction: reaction === 'none' ? null : reaction });
}

export default async (req) => {
  try {
    const url = new URL(req.url);
    const path = url.pathname.replace(/^\/api/, '').replace(/\/+$/, '') || '/';
    const method = req.method.toUpperCase();

    if (path === '/posts' && method === 'GET') return await listPosts(req);
    if (path === '/posts' && method === 'POST') return await createPost(req);
    if (path === '/login' && method === 'POST') {
      const body = await readBody(req);
      const author = authenticate(body.name, body.token);
      return author ? json({ author: publicAuthor(author) }) : fail(401, 'Nombre o contraseña incorrectos.');
    }
    let m;
    if ((m = /^\/posts\/([^/]+)\/react$/.exec(path)) && method === 'POST') return await react(req, m[1]);
    if ((m = /^\/posts\/([^/]+)$/.exec(path)) && method === 'DELETE') return await deletePost(req, m[1]);

    return fail(path.startsWith('/posts') || path === '/login' ? 405 : 404, 'No encontrado.');
  } catch (e) {
    if (e && e.status) return fail(e.status, e.message);
    console.error(e);
    return fail(500, 'Error del servidor.');
  }
};

export const config = { path: '/api/*' };
